package com.chirag.flex.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
public class FileUpload {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String fileUrl;

    private int duration;
    private int days;

    private String locations; // Bangalore,Mumbai

    private double price;

    private String status; // UPLOADED

    @JsonIgnore   // prevents infinite JSON loop (IMPORTANT)
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    // ================= GETTERS =================

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public int getDuration() {
        return duration;
    }

    public int getDays() {
        return days;
    }

    public String getLocations() {
        return locations;
    }

    public double getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    public User getUser() {
        return user;
    }

    // ================= SETTERS =================

    public void setName(String name) {
        this.name = name;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public void setLocations(String locations) {
        this.locations = locations;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
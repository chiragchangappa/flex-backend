package com.chirag.flex.entity;

public enum Role {
    USER,
    ADMIN
}
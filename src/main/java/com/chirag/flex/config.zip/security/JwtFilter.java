package com.chirag.flex.security;

import com.chirag.flex.entity.User;
import com.chirag.flex.repository.UserRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
public class JwtFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwt;

    @Autowired
    private UserRepository repo;

    // ========================
    // SKIP AUTH ENDPOINTS
    // ========================
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getServletPath();
        return path.startsWith("/auth/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain)
            throws ServletException, IOException {

        // ========================
        // HANDLE CORS PRE-FLIGHT
        // ========================
        if ("OPTIONS".equalsIgnoreCase(req.getMethod())) {
            chain.doFilter(req, res);
            return;
        }

        String header = req.getHeader("Authorization");

        System.out.println("AUTH HEADER: " + header);

        // ========================
        // FIX 1: HANDLE MISSING TOKEN
        // ========================
        if (header == null || !header.startsWith("Bearer ")) {
            chain.doFilter(req, res);
            return;
        }

        String token = header.substring(7);

        try {
            String email = jwt.getEmail(token);

            if (email != null &&
                    SecurityContextHolder.getContext().getAuthentication() == null) {

                User user = repo.findByEmail(email).orElse(null);

                if (user != null) {

                    List<SimpleGrantedAuthority> authorities =
                            List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()));

                    UsernamePasswordAuthenticationToken auth =
                            new UsernamePasswordAuthenticationToken(
                                    user.getEmail(),
                                    null,
                                    authorities
                            );

                    SecurityContextHolder.getContext().setAuthentication(auth);

                    System.out.println("JWT AUTH SUCCESS: " + email);
                }
            }

        } catch (Exception e) {
            // ========================
            // FIX 2: CLEAN FAILURE HANDLING
            // ========================
            SecurityContextHolder.clearContext();
            System.out.println("JWT ERROR: " + e.getMessage());
        }

        chain.doFilter(req, res);
    }
}
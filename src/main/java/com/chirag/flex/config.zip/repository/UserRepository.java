package com.chirag.flex.repository;

import com.chirag.flex.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    // 🔍 find user by email (already correct)
    Optional<User> findByEmail(String email);

    // 🔐 find user by reset token
    Optional<User> findByResetToken(String token);
}
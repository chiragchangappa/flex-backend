package com.chirag.flex.repository;

import com.chirag.flex.entity.FileUpload;
import com.chirag.flex.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FileRepository extends JpaRepository<FileUpload, Long> {

    List<FileUpload> findByUser(User user);

    List<FileUpload> findByLocationsContaining(String location);
}
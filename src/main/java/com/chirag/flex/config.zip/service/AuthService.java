package com.chirag.flex.service;

import com.chirag.flex.entity.User;
import com.chirag.flex.entity.Role;
import com.chirag.flex.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;

@Service
public class AuthService {

    @Autowired
    private UserRepository repo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ✅ RUNS ONCE WHEN APP STARTS
    @PostConstruct
    public void makeAdmin() {

        repo.findByEmail("admin@gmail.com").ifPresentOrElse(user -> {

            // ensure role is always correct
            if (user.getRole() == null || user.getRole() != Role.ADMIN) {
                user.setRole(Role.ADMIN);
                repo.save(user);
                System.out.println("Admin role assigned/updated");
            }

        }, () -> {
            // OPTIONAL: auto-create admin if not present
            User admin = new User();
            admin.setEmail("admin@gmail.com");
            admin.setPassword(passwordEncoder.encode("admin123")); // change later
            admin.setRole(Role.ADMIN);

            repo.save(admin);
            System.out.println("Admin created automatically");
        });
    }

    // ✅ SIGNUP
    public String signup(User u) {

        if (repo.findByEmail(u.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        u.setPassword(passwordEncoder.encode(u.getPassword()));
        u.setRole(Role.USER); // default role

        repo.save(u);

        return "Registered successfully";
    }

    // ✅ LOGIN
    public User login(String email, String pass) {

        User user = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(pass, user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        return user;
    }
}
package com.chirag.flex.service;

import com.chirag.flex.entity.Payment;
import com.chirag.flex.repository.PaymentRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.Utils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class PaymentService {

    @Value("${razorpay.key.id}")
    private String keyId;

    @Value("${razorpay.key.secret}")
    private String keySecret;

    @Autowired
    private PaymentRepository paymentRepository;

    // ================= CALCULATE AMOUNT =================
    private Long calculateAmount(String city, int days, int seconds) {

        long pricePerDay = 10; // FIXED BASE PRICE

        long multiplier;

        if (seconds <= 10) {
            multiplier = 1;
        } else if (seconds <= 20) {
            multiplier = 2;
        } else {
            multiplier = 3;
        }

        return pricePerDay * days * multiplier;
    }

    // ================= CREATE ORDER =================
    public Map<String, Object> createOrder(String city, int days, int seconds, String email) throws Exception {

        Long amount = calculateAmount(city, days, seconds);

        RazorpayClient client = new RazorpayClient(keyId, keySecret);

        JSONObject options = new JSONObject();
        options.put("amount", amount * 100); // in paise
        options.put("currency", "INR");
        options.put("receipt", "order_" + System.currentTimeMillis());

        Order order = client.orders.create(options);

        // ✅ SAVE PAYMENT IN DB
        Payment payment = new Payment();
        payment.setAmount(amount * 100);
        payment.setStatus("CREATED");
        payment.setOrderId(order.get("id").toString());
        payment.setUserEmail(email);
        payment.setCreatedAt(LocalDateTime.now());

        paymentRepository.save(payment);

        // ✅ RESPONSE TO FRONTEND
        Map<String, Object> response = new HashMap<>();
        response.put("id", order.get("id"));
        response.put("amount", order.get("amount"));
        response.put("currency", order.get("currency"));

        return response;
    }

    // ================= VERIFY PAYMENT =================
    public void verifyAndUpdatePayment(String orderId,
                                       String paymentId,
                                       String signature) throws Exception {

        boolean isValid = Utils.verifyPaymentSignature(
                new JSONObject()
                        .put("razorpay_order_id", orderId)
                        .put("razorpay_payment_id", paymentId)
                        .put("razorpay_signature", signature),
                keySecret
        );

        if (isValid) {

            Payment payment = paymentRepository.findByOrderId(orderId)
                    .orElseThrow(() -> new RuntimeException("Payment not found"));

            payment.setStatus("SUCCESS");
            paymentRepository.save(payment);

        } else {
            throw new RuntimeException("Invalid signature");
        }
    }
}
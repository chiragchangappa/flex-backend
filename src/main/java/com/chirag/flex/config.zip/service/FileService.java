package com.chirag.flex.service;

import com.chirag.flex.entity.FileUpload;
import com.chirag.flex.entity.User;
import com.chirag.flex.repository.FileRepository;
import com.chirag.flex.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

@Service
public class FileService {

    @Value("${file.upload-dir}")
    String dir;

    @Autowired
    FileRepository repo;

    @Autowired
    UserRepository userRepository;

    // ================= UPLOAD =================
    public String upload(MultipartFile file,
                         String name,
                         int duration,
                         int days,
                         String locations,
                         double price) throws Exception {

        File uploadDir = new File(dir);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();

        // ✅ SAVE FILE
        String path = dir + File.separator + fileName;
        file.transferTo(new File(path));

        String email = (String) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        FileUpload f = new FileUpload();
        f.setName(name);

        // ⚠️ store ONLY filename or relative path (clean)
        f.setFileUrl(fileName);

        f.setDuration(duration);
        f.setDays(days);
        f.setLocations(locations);
        f.setPrice(price);
        f.setStatus("UPLOADED");
        f.setUser(user);

        repo.save(f);

        return "Uploaded Successfully";
    }

    // ================= GET =================
    public List<FileUpload> myFiles() {

        String email = (String) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return repo.findByUser(user);
    }

    // ================= DELETE =================
    public void delete(Long id) {

        FileUpload file = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Not found"));

        String email = (String) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!file.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Not allowed");
        }

        // ✅ DELETE FROM SAME DIR
        File f = new File(dir + File.separator + file.getFileUrl());

        if (f.exists()) {
            f.delete();
        }

        repo.deleteById(id);
    }
}

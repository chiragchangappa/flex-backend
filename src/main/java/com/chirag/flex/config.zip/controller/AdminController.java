package com.chirag.flex.controller;

import com.chirag.flex.entity.FileUpload;
import com.chirag.flex.repository.FileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired 
    FileRepository repo;

    // 🔍 Search by location
    @GetMapping("/search")
    public List<FileUpload> search(@RequestParam String location){

        List<FileUpload> files = repo.findByLocationsContaining(location);

        for (FileUpload f : files) {

            String fileName = new File(f.getFileUrl()).getName();

            // overwrite fileUrl with download link
            f.setFileUrl("http://localhost:8080/admin/download/" + fileName);
        }

        return files;
    }

    // 📥 Download file
    @GetMapping("/download/{filename}")
    public byte[] download(@PathVariable String filename) throws Exception {

        File file = new File("c:/flex-uploads/" + filename);

        if (!file.exists()) {
            throw new RuntimeException("File not found");
        }

        return Files.readAllBytes(file.toPath());
    }
}
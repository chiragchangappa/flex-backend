package com.chirag.flex.controller;

import com.chirag.flex.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin(origins = "*")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    // ================= CREATE ORDER =================
    @GetMapping("/create")
    public ResponseEntity<?> createOrder(@RequestParam String city,
                                         @RequestParam int days,
                                         @RequestParam int seconds,
                                         @RequestParam String email) {
        try {
            return ResponseEntity.ok(
                    paymentService.createOrder(city, days, seconds, email)
            );
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error creating order: " + e.getMessage());
        }
    }

    // ================= VERIFY PAYMENT =================
    @PostMapping("/verify")
    public ResponseEntity<?> verifyPayment(@RequestParam String orderId,
                                           @RequestParam String paymentId,
                                           @RequestParam String signature) {
        try {
            paymentService.verifyAndUpdatePayment(orderId, paymentId, signature);
            return ResponseEntity.ok("Payment Successful");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(400).body("Payment Failed: " + e.getMessage());
        }
    }
}
package com.chirag.flex.controller;

import com.chirag.flex.dto.ResetRequest;
import com.chirag.flex.entity.User;
import com.chirag.flex.repository.UserRepository;
import com.chirag.flex.service.AuthService;
import com.chirag.flex.service.EmailService;
import com.chirag.flex.security.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private JwtUtil jwt;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ========================
    // SIGNUP
    // ========================
    @PostMapping("/signup")
    public String signup(@RequestBody User u) {
        return authService.signup(u);
    }

    // ========================
    // LOGIN
    // ========================
    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> d) {

        User user = authService.login(
                d.get("email"),
                d.get("password")
        );

        String token = jwt.generate(
                user.getEmail(),
                user.getRole().name()
        );

        return Map.of(
                "token", token,
                "role", user.getRole().name()
        );
    }

    // ========================
    // FORGOT PASSWORD
    // ========================
    @PostMapping("/forgot-password")
    public String forgot(@RequestParam String email) {

        User user = userRepo.findByEmail(email).orElse(null);

        if (user == null) {
            return "User not found";
        }

        String token = UUID.randomUUID().toString();

        user.setResetToken(token);
        user.setTokenExpiry(LocalDateTime.now().plusMinutes(15));

        userRepo.save(user);

        String link = "http://localhost:5500/reset.html?token=" + token;

        emailService.sendResetEmail(email, link);

        return "Reset link sent to email";
    }

    // ========================
    // RESET PASSWORD
    // ========================
    @PostMapping("/reset-password")
    public String reset(@RequestBody ResetRequest req) {

        User user = userRepo.findByResetToken(req.getToken()).orElse(null);

        if (user == null) {
            return "Invalid token";
        }

        if (user.getTokenExpiry() == null ||
                user.getTokenExpiry().isBefore(LocalDateTime.now())) {
            return "Token expired";
        }

        // ✅ FIXED PASSWORD ENCODING
        user.setPassword(passwordEncoder.encode(req.getPassword()));

        user.setResetToken(null);
        user.setTokenExpiry(null);

        userRepo.save(user);

        return "Password updated successfully";
    }
}
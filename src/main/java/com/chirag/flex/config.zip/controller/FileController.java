package com.chirag.flex.controller;

import com.chirag.flex.entity.FileUpload;
import com.chirag.flex.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/files")
public class FileController {

    @Autowired FileService s;

    @PostMapping("/upload")
    public String upload(@RequestParam MultipartFile file,
                         @RequestParam String name,
                         @RequestParam int duration,
                         @RequestParam int days,
                         @RequestParam String locations,
                         @RequestParam double price) throws Exception {

        return s.upload(file,name,duration,days,locations,price);
    }

    @GetMapping
    public List<FileUpload> get(){
        return s.myFiles();
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id){
        s.delete(id);
    }
}